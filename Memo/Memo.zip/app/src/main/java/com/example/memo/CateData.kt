package com.example.memo

class CateData {
    var idx :Int = 0
    var name :String = ""

    constructor(idx: Int, name: String) {
        this.idx = idx
        this.name = name
    }
}