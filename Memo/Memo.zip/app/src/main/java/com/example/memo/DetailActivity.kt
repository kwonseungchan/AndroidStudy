package com.example.memo

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.w3c.dom.Text

class DetailActivity : AppCompatActivity() {
    lateinit var memoArr : ArrayList<CateData>
    var idx = -1
    lateinit var inputEt : EditText
    lateinit var titleTv : TextView
    lateinit var cateBt : Button
    lateinit var mainRv: RecyclerView
    lateinit var adapter : MainRvAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        inputEt = findViewById(R.id.inputEt)
        titleTv = findViewById(R.id.titleTv)
        cateBt = findViewById(R.id.cateBt)
        mainRv = findViewById(R.id.mainRv)

        idx = intent.getIntExtra("idx", -1);


        memoArr = ArrayList()

        adapter = MainRvAdapter(this)
        mainRv.layoutManager = LinearLayoutManager(this)
        mainRv.adapter = adapter

        getDataFromDb(idx)

        cateBt.setOnClickListener {
            var db: SQLiteDatabase = openOrCreateDatabase("sql_test.db", Context.MODE_PRIVATE, null)

            var str = "INSERT INTO memo (content,cate_idx) VALUES ('" + inputEt.text.toString()+ "',$idx)"

            db.execSQL(str)
            db.close()
            inputEt.setText("")
            getDataFromDb(idx)
        }

    }

    fun getDataFromDb(idx : Int){
        var db: SQLiteDatabase = openOrCreateDatabase("sql_test.db", Context.MODE_PRIVATE, null)
        val c: Cursor = db.rawQuery("SELECT * FROM memo WHERE cate_idx="+idx, null)

        c.moveToFirst()
        memoArr.clear()
        while (c.isAfterLast() === false) {
            var idx = c.getInt(0)
            var content = c.getString(1)
            memoArr.add(CateData(idx, content))

            c.moveToNext()
        }
        c.close()
        db.close()
        adapter.notifyDataSetChanged()
    }


    inner class MainRvAdapter(val context: Context) :
        RecyclerView.Adapter<MainRvAdapter.Holder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view = LayoutInflater.from(context).inflate(R.layout.item, parent, false)
            return Holder(view)
        }

        override fun getItemCount(): Int {
            return memoArr.size
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            holder.tv1.setText(memoArr.get(position).idx.toString())
            holder.tv2.setText(memoArr.get(position).name)

            holder.itemView.setOnClickListener {

            }

        }

        inner class Holder(itemView: View?) : RecyclerView.ViewHolder(itemView!!) {
            var tv1: TextView = itemView!!.findViewById(R.id.engTv)
            val tv2: TextView = itemView!!.findViewById(R.id.korTv)
        }
    }
}