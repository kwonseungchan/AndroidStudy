package com.example.memo

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var cateArr : ArrayList<CateData>

    lateinit var inputEt :EditText
    lateinit var cateBt :Button
    lateinit var mainRv:RecyclerView
    lateinit var adapter : MainRvAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        inputEt = findViewById(R.id.inputEt)
        cateBt = findViewById(R.id.cateBt)
        mainRv = findViewById(R.id.mainRv)

        cateArr = ArrayList()

        dbInit()

        adapter = MainRvAdapter(this)
        mainRv.layoutManager = LinearLayoutManager(this)
        mainRv.adapter = adapter

        getDataFromDb()

        cateBt.setOnClickListener {
           addCate()
           getDataFromDb()

        }

    }

    fun getDataFromDb(){
        var db: SQLiteDatabase = openOrCreateDatabase("sql_test.db", Context.MODE_PRIVATE, null)
        val c: Cursor = db.rawQuery("SELECT * FROM cate", null)

        c.moveToFirst()
        cateArr.clear()
        while (c.isAfterLast() === false) {
            var idx = c.getInt(0)
            var name = c.getString(1)
            cateArr.add(CateData(idx, name))

            c.moveToNext()
        }
        c.close()
        db.close()
        adapter.notifyDataSetChanged()
    }

    fun addCate(){
        var db: SQLiteDatabase = openOrCreateDatabase("sql_test.db", Context.MODE_PRIVATE, null)

        var str = "INSERT INTO cate (name) VALUES ('" + inputEt.text.toString()+ "')"
        Log.d("aabb","str: "+str)
        db.execSQL(str)
        db.close()
        inputEt.setText("")
    }

    fun dbInit(){
        var db: SQLiteDatabase = openOrCreateDatabase("sql_test.db", Context.MODE_PRIVATE, null)

        var sql = "CREATE TABLE IF NOT EXISTS cate(" +
                    "idx INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT)"
        db.execSQL(sql)

        sql = "CREATE TABLE IF NOT EXISTS memo(" +
                "idx INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "content TEXT, cate_idx INTEGER)"
        db.execSQL(sql)

        db.close()
    }

    inner class MainRvAdapter(val context: Context) :
        RecyclerView.Adapter<MainRvAdapter.Holder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view = LayoutInflater.from(context).inflate(R.layout.item, parent, false)
            return Holder(view)
        }

        override fun getItemCount(): Int {
            return cateArr.size
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            holder.tv1.setText(cateArr.get(position).idx.toString())
            holder.tv2.setText(cateArr.get(position).name)

            holder.itemView.setOnClickListener {
                var intent = Intent(this@MainActivity, com.example.memo.DetailActivity::class.java)
                intent.putExtra("idx", cateArr.get(position).idx)
                startActivity(intent)
            }

        }

        inner class Holder(itemView: View?) : RecyclerView.ViewHolder(itemView!!) {
            var tv1: TextView = itemView!!.findViewById(R.id.engTv)
            val tv2: TextView = itemView!!.findViewById(R.id.korTv)
        }
    }
}