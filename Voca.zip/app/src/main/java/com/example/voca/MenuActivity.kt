package com.example.voca

import android.app.Instrumentation
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import java.util.*


class MenuActivity : AppCompatActivity(), View.OnClickListener {
    lateinit var manageBt: Button
    lateinit var gameBt: Button
    lateinit var quitBt: Button
    lateinit var startForResult: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
        manageBt = findViewById(R.id.manageBt)
        gameBt = findViewById(R.id.gameBt)
        quitBt = findViewById(R.id.quitBt)

        /** test ***/
        MainActivity.oriVocaArr.add(Voca("cat", "고양이"))
        MainActivity.oriVocaArr.add(Voca("dog", "개"))
        MainActivity.oriVocaArr.add(Voca("horse", "말"))
        MainActivity.oriVocaArr.add(Voca("octopus", "문어"))
        /******/
        var str : String = ""
        for (i in 0 until MainActivity.oriVocaArr.size step 1){
            var voca = MainActivity.oriVocaArr.get(i)
            str = str+ voca.eng+","
        }
        str = str.substring(0, str.length-1)

        var pref : SharedPreferences = getSharedPreferences("wordPref", MODE_PRIVATE)
        var edit : SharedPreferences.Editor = pref.edit()
        edit.putString("keys",str)

        for (i in 0 until MainActivity.oriVocaArr.size step 1){
            var voca = MainActivity.oriVocaArr.get(i)
            edit.putString(voca.eng,voca.kor)
        }


        edit.commit()

        var arr = str.split("@")
        for (i in 0 until arr.size step 1){
            var temp = arr.get(i)
            var arr2 = temp.split(",")
            var voca  = Voca(arr2[0], arr2[1])
        }


        manageBt.setOnClickListener {
            var intent: Intent = Intent(this, com.example.voca.MainActivity::class.java)
            startActivity(intent)

        }

        gameBt.setOnClickListener(this)

        quitBt.setOnClickListener {
//            finish()
            var arr   = arrayOf("류재민","추정호","박정재","최용호","권승찬","김승재","이도훈","김건호","조성철","유재형")
            Log.d("aabb","size: "+arr.size)
            manageBt.setText(arr.get(Random().nextInt(arr.size)))



        }
    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.gameBt -> {
                var intent = Intent(this, com.example.voca.GameActivity::class.java)
                startActivity(intent)
            }
        }


    }
}