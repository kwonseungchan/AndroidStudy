package com.mp.boradgame

class Country {
    var country : String = ""
    var payment : Int = 0
    var territory : Int = 0
    var building : Int = 0
    var countryImage : Int = 0
    constructor(country : String, payment : Int, territory : Int, building : Int, countryImage : Int){
        this.country = country
        this.payment = payment
        this.territory = territory
        this.building = building
        this.countryImage = countryImage
    }
}