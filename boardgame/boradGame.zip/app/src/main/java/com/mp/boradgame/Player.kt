package com.mp.boradgame

class Player {
    var position : Int = 0
    var playerMoney : Int = 0
    var exPosition : Int = 0
    constructor(playerMoney : Int, position : Int, exPosition : Int){
        this.playerMoney = playerMoney
        this.position = position
        this.exPosition = exPosition
    }
}