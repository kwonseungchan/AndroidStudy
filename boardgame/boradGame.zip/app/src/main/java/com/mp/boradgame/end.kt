package com.mp.boradgame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.content.Intent




class end : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end)



        var result : TextView
        var value = intent.getIntExtra("player",0)

        result = findViewById(R.id.result)

        result.setText("승자는 player"+value + " 입니다!!")

       // val intent = Intent(this@end, MainActivity::class.java)










    }
}