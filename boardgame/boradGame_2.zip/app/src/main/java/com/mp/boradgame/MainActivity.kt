package com.mp.boradgame

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.MainThread
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.collections.ArrayList
import kotlin.concurrent.timer


class MainActivity : AppCompatActivity() {
    var arr: ArrayList<Country> = ArrayList()
    var players: ArrayList<Player> = ArrayList()
    var keys : ArrayList<Int> = ArrayList() //황금열쇠

    lateinit var progressBar: ProgressBar
    lateinit var btn: Button
    lateinit var adapter: MainRvAdapter //커스텀 아답터 만들기
    lateinit var rv: RecyclerView

    lateinit var scoreP1: TextView
    lateinit var scoreP2: TextView

    lateinit var finishGame : Button

    val random = Random()


    var turn: Int = 0
    var player1_drift : Int = 0
    var player2_drift : Int = 0

    private fun init() {
        showProgress(false)
    }

    fun showProgress(isShow: Boolean) {
        if (isShow) progressBar.visibility = View.VISIBLE
        else {
            progressBar.visibility = View.INVISIBLE
        }
    }



    fun winner(player: Int, x: Int) {
        var intent: Intent = Intent(this, com.mp.boradgame.end::class.java)
        if (player == 0) {
            if (x < 0) {
                handler.removeMessages(0)
                intent.putExtra("player", 2) //플레이어 2가 이김
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent)
            }
        } else if (player == 1) {
            if (x < 0) {
                handler.removeMessages(0)
                intent.putExtra("player", 1) //플레이어 1이 이김
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent)
            }
        }
        return
    }

    fun makeRand(): Int {
        return random.nextInt(6) + 1
    }

    fun p1_checkHappen(position: Int): Int {
        if (arr[position].territory == 0) return 1    //땅의 주인이 없을때
        else if (arr[position].territory == 1) return 2    //내가 땅의 주인 일때
        else if (arr[position].territory == 2) return 3     //남의 땅에 도착
        else if (arr[position].territory == 3) return 4;    //무인도에 도착
        return -1; // 땅의 주인에 이상한 값이 들어감;;
    }

    fun p2_checkHappen(position: Int): Int {
        if (arr[position].territory == 0) return 1    //땅의 주인이 없을때
        else if (arr[position].territory == 2) return 2    //내가 땅의 주인 일때
        else if (arr[position].territory == 1) return 3     //남의 땅에 도착
        else if (arr[position].territory == 3) return 4;    //무인도에 도착

        return -1; // 땅의 주인에 이상한 값이 들어감!!
    }
    fun haveDrift(player: Int, n : Int){
        if (player == 1) {  //플레이어 1
            players[0].isdrift = 1

        } else {            //플레이어 2
            players[1].isdrift= 1
        }

    }
    fun buyCountry(player: Int, n: Int) {
        var idx: Int = 0
        if (player == 1) {
            idx = 0
        } else if (player == 0) {
            idx = 1
        }
        var buycountry: AlertDialog.Builder = AlertDialog.Builder(this)
        buycountry.setTitle("땅이 비어져있습니다!!")
        buycountry.setMessage(
            "player" + (idx + 1) + "의 차례 주사위는 " + n + "" +
                    "\n" + "위치는 : " + arr[players[idx].position].country +
                    "\n" + "땅의 비용은 :" + arr[players[idx].position].payment
        )
        buycountry.setNegativeButton(
            "아니요",
            object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {

                }
            })
        buycountry.setPositiveButton(
            "구매",
            object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    if (players[idx].playerMoney > arr[players[idx].position].payment) {
                        Log.d(
                            "payment!!",
                            "playerMoney : " + players[idx].playerMoney
                        )
                        players[idx].playerMoney -= arr[players[idx].position].payment
                        arr[players[idx].position].territory = idx + 1
                        if (idx == 0) {
                            scoreP1.setText("\tplayer1의 돈\n\t" + players[idx].playerMoney+"원")
                            adapter.notifyDataSetChanged()
                        } else if (idx == 1) {
                            scoreP2.setText("\tplayer2의 돈\n\t"+ players[idx].playerMoney+"원")
                            adapter.notifyDataSetChanged()
                        }

                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            "돈이 없습니다",
                            Toast.LENGTH_LONG
                        ).show()
                        adapter.notifyDataSetChanged()
                    }
                }

            })
        buycountry.setCancelable(false) //무조건 버튼을 눌러야 꺼짐(back 삭제키 안먹음
        buycountry.show()
    }
    ////게임종료 함수
    fun exitGame(){
        var exit: AlertDialog.Builder = AlertDialog.Builder(this)
        exit.setTitle("정말로 게임을 종료하시겠습니까?")
        exit.setMessage(
            "지금까지 한 게임의 데이터를 모두 잃습니다.. 그래도 하시겠습니까?"
        )
        exit.setNegativeButton(
            "아니요",
            object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {

                }
            })
        exit.setPositiveButton(
            "예",
            object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    finish()
                }
            })
        exit.setCancelable(false) //무조건 버튼을 눌러야 꺼짐(back 삭제키 안먹음
        exit.show()
    }
    //**************************************************
    fun buyBuilding(player: Int, n: Int) {
        var idx: Int = 0
        if (player == 1) {
            idx = 0
        } else if (player == 0) {
            idx = 1
        }
        var buycountry: AlertDialog.Builder = AlertDialog.Builder(this)
        buycountry.setTitle("자신의 땅에 도착했습니다!!")
        buycountry.setMessage(
            "player" + (1 + idx) + " 차례 주사위의 눈은 " + n + "" +
                    "\n" + "위치는 : " + arr[players[idx].position].country +
                    "\n" + "빌딩의 건설 비용은 1000원이고 추가적으로 땅값이 4000원 상승합니다"
        )
        buycountry.setNegativeButton(
            "아니요",
            object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {

                }
            })
        buycountry.setPositiveButton(
            "구매",
            object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    if (players[idx].playerMoney >= 1000) {
                        players[idx].playerMoney -= 1000
                        arr[players[idx].position].building = 1
                        arr[players[idx].position].payment += 4000
                        if (idx == 0) {
                            scoreP1.setText("\tplayer1의 돈\n\t"+ players[idx].playerMoney+"원")
                        } else if (idx == 1) {
                            scoreP2.setText("\tplayer2의 돈\n\t"+ players[idx].playerMoney+"원")
                        }
                        adapter.notifyDataSetChanged()
                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            "돈이 없습니다",
                            Toast.LENGTH_LONG
                        ).show()
                        adapter.notifyDataSetChanged()

                    }
                }
            })
        buycountry.setCancelable(false) //무조건 버튼을 눌러야 꺼짐(back 삭제키 안먹음
        buycountry.show()

    }

    //*************************************************
    fun payOther(player: Int, n: Int) {
        var idx: Int = 0
        if (player == 1) {
            idx = 0
        } else if (player == 0) {
            idx = 1
        }
        var buycountry: AlertDialog.Builder = AlertDialog.Builder(this)
        buycountry.setTitle("남의 땅에 도착했습니다!!")
        buycountry.setMessage(
            "player" + (idx + 1) + "차례 주사위의 눈은 " + n +
                    "\n" + "비용은 " + arr[players[idx].position].payment + "원 입니다"
                    + "\n" + "위치는 : " + arr[players[idx].position].country
        )
        buycountry.setNegativeButton(
            "지불",
            object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    if (players[idx].playerMoney < arr[players[idx].position].payment) {
                        winner(idx, players[idx].playerMoney - arr[players[idx].position].payment)
                    } else {
                        players[idx].playerMoney -= arr[players[idx].position].payment
                        if (idx == 0) {
                            scoreP1.setText("\tplayer1의 돈\n\t" + players[idx].playerMoney+"원")
                        } else if (idx == 1) {
                            scoreP2.setText("\tplayer2의 돈\n\t" + players[idx].playerMoney+"원")
                        }
                    }
                    adapter.notifyDataSetChanged()
                }

            })
        buycountry.setCancelable(false) //무조건 버튼을 눌러야 꺼짐(back 삭제키 안먹음
        buycountry.show()

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var n: Int

        progressBar = findViewById(R.id.progressBar)
        rv = findViewById(R.id.rv)
        btn = findViewById(R.id.btn)

        scoreP1 = findViewById((R.id.scoreP1))
        scoreP2 = findViewById((R.id.scoreP2))

        finishGame = findViewById((R.id.finishGame))

        progressBar.max = 30

        adapter = MainRvAdapter(this, arr)  // 아답터와 데이터를 연결
        rv.adapter = adapter // 리싸이클러 뷰와 아답터를 연결
        rv.layoutManager = LinearLayoutManager(this) //리사이클뷰의 형식 만들기

        players.add(Player(100000, 0, 0, 0))
        players.add(Player(100000, 0, 0, 0))

        arr.add(Country("한국", 4000, 0, 0,R.drawable.korea))
        arr.add(Country("일본", 3000, 0, 0,R.drawable.japen))
        arr.add(Country("중국", 1000, 0, 0,R.drawable.china))
        arr.add(Country("미국", 5000, 0, 0,R.drawable.america))
        arr.add(Country("무인도",0,3,0,R.drawable.island))
        arr.add(Country("이스라엘", 3000, 0, 0,R.drawable.isral))
        arr.add(Country("스위스", 4000, 0, 0,R.drawable.swiss))
        arr.add(Country("캐나다", 2000, 0, 0,R.drawable.canada))

        scoreP1.setText("\tplayer1의 돈\n\t100000원")
        scoreP2.setText("\tplayer2의 돈\n\t100000원")

        ///********************게임 종료 버튼 //////////
        finishGame.setOnClickListener {
            exitGame()
        }


        //**********************버튼 입력 부분 *********************************************************************
        btn.setOnClickListener {
            showProgress(true)
            var progress = progressBar.progress
            n = 0
            winner(0,players[0].playerMoney)
            winner(1, players[1].playerMoney)


            Log.d("drift", "지금의 턴은? "+ turn);

            handler.removeMessages(0)
            handler.sendEmptyMessageDelayed(0, 30000)
            progressBar.progress++
            ////////////1. 플레이어 들의 말 움직임 !!***************************************

            ////////////******플레이어1이나 2가 무인도에 있을 때
            if((players[0].isdrift == 1 && turn == 0) || players[1].isdrift == 1 && turn == 1 ){

                if(players[0].isdrift == 1 && turn == 0){   //player 1
                    if(player1_drift == 0){
                        Toast.makeText(this,"플레이어 1이 무인도에 도착하셨습니다!", Toast.LENGTH_LONG).show()
                    }
                    player1_drift++
                    players[0].position = 4
                    if(player1_drift == 3){
                        Toast.makeText(this, "플레이어 1이 무인도에서 탈출했습니다", Toast.LENGTH_LONG).show()
                        player1_drift = 0
                        players[0].isdrift = 0

                        n = makeRand()
                        players[0].position = 4 + n
                        if (players[0].position > 7) {
                            // Log.d("payment", "payment" + players[0].position)
                            Toast.makeText(this, "플레이어 1가 한바퀴를 돌았습니다!!", Toast.LENGTH_LONG).show()
                            players[0].position = players[0].position % 8
                            players[0].playerMoney += 2000

                        }

                        turn = 1
                    }
                    turn = 1

                }
                else if(players[1].isdrift == 1 && turn == 1){ //player2
                    if(player2_drift == 0){
                        Toast.makeText(this,"플레이어 2가 무인도에 도착하셨습니다!", Toast.LENGTH_LONG).show()
                    }
                    player2_drift++
                    players[1].position = 4
                    if(player2_drift == 3){
                        Toast.makeText(this, "플레이어 2가 무인도에서 탈출했습니다", Toast.LENGTH_LONG).show()

                        Log.d("drift", player2_drift.toString() + " 이어서 p2 탈출!!!")
                        player2_drift = 0
                        players[1].isdrift = 0
                        n = makeRand()
                        players[1].position = 4 + n
                        if (players[1].position > 7) {
                            // Log.d("payment", "payment" + players[0].position)
                            Toast.makeText(this, "플레이어 2가 한바퀴를 돌았습니다!!", Toast.LENGTH_LONG).show()
                            players[1].position = players[1].position % 8
                            players[1].playerMoney += 2000

                        }

                        turn = 0

                    }
                    turn = 0


                }
            }
//********************플레이어 1일때 주사위 설정***********************
            else if (turn == 0 || turn == 3) {
                Log.d("turn!!", "player1 "+players[0].position.toString() + " 입니다!!!")

                players[0].exPosition = players[0].position

                n = makeRand()
                Log.d("random", "random : " + n.toString())
                players[0].position = players[0].exPosition + n


                turn = 1

                if (players[0].position > 7) {
                   // Log.d("payment", "payment" + players[0].position)
                    Toast.makeText(this, "플레이어 1가 한바퀴를 돌았습니다!!", Toast.LENGTH_LONG).show()
                    players[0].position = players[0].position % 8
                    players[0].playerMoney += 2000

                }

            }
//*********************플레이어 2일때 주사위 설정***********************
            else {
                Log.d("turn2!!", "player2 " +players[1].position.toString() + " 입니다!!!")

                players[1].exPosition = players[1].position

                n = makeRand()
                players[1].position = players[1].exPosition + n
                turn = 0


                if (players[1].position > 7) {

                    Toast.makeText(this, "플레이어 2가 한바퀴를 돌았습니다!!", Toast.LENGTH_LONG).show()
                    players[1].position = players[1].position % 8;
                    players[1].playerMoney += 2000
                }

            } ///1. 플레이어 들의 말 움직임이 끝나는 부분 !!


            //********************************player 1게임차례 ***********************************************

            if (turn == 1) {//player 1

                var behavior: Int = p1_checkHappen(players[0].position)
                Log.d("happen", "behavior" + behavior)
                when (behavior) {
                    1 -> { // 주인없는 땅에 도착
                        buyCountry(turn, n)
                    }
                    2 -> {  //빌딩을 살때
                        buyBuilding(turn, n)
                    }
                    3 -> {  //남에 땅에 도착할 때
                        payOther(turn,n)
                    }
                    4 -> {
                        haveDrift(turn, n)
                    }
                    -1 -> {
                        finish()
                    }
                }


            }
            ///////***********player2 게임 차레 *******************************

            if (turn == 0)//player 2
            {
                var behavior: Int = p2_checkHappen(players[1].position)
                when (behavior) {
                    1 -> {
                        buyCountry(turn, n)
                    }
                    2 -> {
                        buyBuilding(turn, n)
                    }
                    3 -> {
                        payOther(turn, n)
                    }
                    4 -> {
                        haveDrift(turn, n)
                    }
                    -1 -> {
                        finish()
                    }
                }
            }
            adapter.notifyDataSetChanged() //arraylist가 변경된 값을 adapter로 리사이클뷰에 전송

            Log.d("drift", "바뀐 턴은 !!! : turn   " + turn)
        }//버튼 클릭 끝날때
    }

    var handler = object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            when (msg.what) {
                0 -> {
                    Toast.makeText(this@MainActivity, "30초안에 주사위를 굴리지 않았습니다", Toast.LENGTH_LONG)
                        .show()

                    showProgress(false)
                    if (turn == 1) {
                        turn = 0
                        Toast.makeText(this@MainActivity, "player2의 차례입니다", Toast.LENGTH_LONG)
                            .show()
                        showProgress((true))
                        sendEmptyMessageDelayed(0, 30000)
                    } else if (turn == 0) {
                        turn = 1;
                        Toast.makeText(this@MainActivity, "player1의 차례입니다", Toast.LENGTH_LONG)
                            .show()
                        showProgress(true)
                        sendEmptyMessageDelayed(0, 30000)

                    }
                }
                1 -> {
                    Toast.makeText(this@MainActivity, "말이 이동합니다", Toast.LENGTH_LONG).show()

                }
            }
        }
    }

    inner class MainRvAdapter(val context: Context, val arr: ArrayList<Country>) :
        RecyclerView.Adapter<MainRvAdapter.Holder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view = LayoutInflater.from(context).inflate(R.layout.board, parent, false)
            return Holder(view)
        }

        override fun getItemCount(): Int { //몇바퀴를 돌리지를 지정
            return arr.size
        }

        override fun onBindViewHolder(
            holder: Holder,
            position: Int
        ) {    //holder는 줄이다!! main에 출력하는 부분
            //position은 바퀴 횟수수
            //postion은 그냥 쭉 돈다
            //Log.d("aa", "실행됨: "+arr.get(position).country)
            holder.tv.setText("\t\t"+arr.get(position).country + "\n통행세 : " + arr.get(position).payment+"원")                   //holder에서 선언된 부분을 수정하는 부분
            holder.flag.setBackgroundResource(arr.get(position).countryImage)
            if (arr[position].territory == 1) {
                holder.tv.setTextColor(Color.RED)
            } else if (arr[position].territory == 2) {
                holder.tv.setTextColor(Color.BLUE)
            } else {
                holder.tv.setTextColor(Color.BLACK)
            }
            if (arr[position].building == 1 || arr[position].building == 2) {
                holder.building.visibility = View.VISIBLE
            } else {
                holder.building.visibility = View.INVISIBLE
            }
            if (players[0].position == position) {
                holder.p1.visibility = View.VISIBLE
            } else {
                holder.p1.visibility = View.INVISIBLE
            }
            if (players[1].position == position) {
                holder.p2.visibility = View.VISIBLE

            } else {
                holder.p2.visibility = View.INVISIBLE
            }


        }

        inner class Holder(itemView: View?) : RecyclerView.ViewHolder(itemView!!) { ////선언만!!!
            val tv: TextView = itemView!!.findViewById(R.id.tv)
            val building: ImageView = itemView!!.findViewById(R.id.building)
            val p1: ImageView = itemView!!.findViewById(R.id.player1)
            val p2: ImageView = itemView!!.findViewById(R.id.player2)
            val flag : TextView = itemView!!.findViewById(R.id.flag)


        }
    }

}

